# CareerAI — AI-Powered Job Search, Resume & Career Assistant

A full-stack implementation of the use-case diagram: job seeker tools (resume
upload/build, AI resume analysis, job matching, safety-checked job search,
application tracker, mock interviews, CareerBot chatbot), a recruiter portal
(post jobs, AI-ranked candidates, applicant tracking, analytics), and an
admin portal (user management, company verification, flagged-job review,
platform analytics).

**Stack:** FastAPI + SQLite (backend), React + Vite (frontend). No paid API
key is required — every "AI" feature (resume scoring, job matching, scam
detection, mock interview scoring, the chatbot) runs on built-in NLP/heuristics
(TF-IDF similarity via scikit-learn + rule-based analysis) so the app works
completely offline out of the box.

## 1. Backend setup

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

# create demo users + sample jobs (recommended for first run)
python seed.py

# start the API on http://localhost:8000
uvicorn app.main:app --reload
```

Demo accounts created by `seed.py`:

| Role       | Email                    | Password      |
|------------|---------------------------|---------------|
| Job seeker | seeker@careerai.com       | seeker123     |
| Recruiter  | recruiter@careerai.com    | recruiter123  |
| Admin      | admin@careerai.com        | admin123      |

Interactive API docs: `http://localhost:8000/docs`

## 2. Frontend setup

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`. The Vite dev server proxies `/api` requests to
the backend at `localhost:8000` (see `vite.config.js`), so no extra CORS
setup is needed in dev.

## 3. What maps to the diagram

**Job Seeker**
- Register/Login, Manage Profile, Upload/Build Resume
- AI Resume Analyzer (score, mistakes, suggestions) + Improve Resume
- Search Jobs, AI Job Matching (match %, missing skills, keywords)
- AI Job Safety Analysis (scam detection) & AI Job Quality Analysis on every listing
- AI Job Readiness Score, AI Project Relevance Analysis
- Save/Shortlist Jobs, Apply for Jobs, Generate Cover Letter
- Application Tracker (Saved → Applied → Shortlisted → Interview → Selected/Rejected), with notes/follow-ups
- AI Apply-or-Improve Advisor + Skill Gap & Learning Roadmap
- AI Mock Interview with per-answer feedback and an overall score
- **AI Video Interview**: CareerBot reads each question aloud (browser text-to-speech), you answer on camera, your speech is transcribed live (browser speech-to-text) and scored by the same interview-scoring engine, and each answer is recorded and downloadable
- Salary Insights, Notifications
- CareerBot chatbot (job search, resume help, interview prep, career guidance, skills, salary, motivation)

**Recruiter/Employer**
- Register/Login, Company Profile, Post/Manage Jobs (auto safety+quality checked)
- View Applicants, AI Candidate Matching & Ranking, Shortlist/Advance candidates
- Recruiter analytics dashboard

**Admin**
- Manage Users, Verify Recruiters/Companies
- Manage Jobs & Categories, review AI-flagged/fake jobs
- Manage Reports/Complaints (job seekers can file a report on any job)
- Platform Analytics

**Not implemented as full features (out of scope for this pass), noted for
future work:** in-app messaging/networking, certifications/badges, and
company review pages shown in "Other System Highlights" on the diagram —
the data model (`Notification`, `Report`) is there to extend into these.

## 4. AI Video Interview notes

The video interview (`/video-interview`) runs entirely in the browser using
standard Web APIs — no video is uploaded to the server and no extra service
or API key is required:

- **Camera/mic**: `getUserMedia` for the live preview and `MediaRecorder` to
  record each answer locally (downloadable as `.webm`).
- **AI asks the question**: the browser's built-in `SpeechSynthesis` reads
  each question aloud.
- **Live transcription**: the browser's `SpeechRecognition`
  (`webkitSpeechRecognition`) converts your spoken answer to text in real
  time, editable before you submit.
- **Scoring**: the transcript is sent to the same `/interview/answer`
  endpoint used by the text-based Mock Interview, so it's scored by the
  identical STAR-method heuristic in `services.score_interview_answer`.

Live transcription currently requires a Chromium-based browser (Chrome,
Edge) — Safari/Firefox don't support the Web Speech API yet, so on those
browsers the page falls back to manual typing while camera recording still
works fine.

## 5. Optional: real LLM output

By default, cover letters and the chatbot use solid template/rule-based
generation (no API key needed). To use a real Claude-style completion for
richer free-text output, set an environment variable before starting the
backend:

```bash
export LLM_API_KEY=sk-ant-...
```

`app/services.py` will automatically use it via `llm_complete()`; if it's
unset or a call fails, the app falls back to the built-in generator
transparently.

## 6. Project structure

```
backend/
  app/
    main.py          FastAPI app + router registration
    models.py         SQLAlchemy models (User, Resume, Job, Application, ...)
    schemas.py         Pydantic request/response schemas
    security.py        JWT auth, password hashing (stdlib pbkdf2, no extra deps)
    services.py         All "AI" logic: parsing, ATS scoring, matching,
                         scam detection, cover letters, mock interview, chatbot
    routers/
      auth.py, seeker.py, recruiter.py, admin.py, chatbot.py
  seed.py               Demo data
  requirements.txt

frontend/
  src/
    api/client.js        Axios instance with JWT header + 401 handling
    context/AuthContext.jsx
    components/          Navbar, JobCard, ScoreRing, ChatWidget, ProtectedRoute
    pages/
      Login.jsx, Register.jsx
      seeker/    Dashboard, ResumeCenter, JobSearch, JobDetails, ApplicationTracker, MockInterview, VideoInterview
      recruiter/ RecruiterDashboard, PostJob, ManageJobs
      admin/     AdminDashboard, Users, JobsReports
```

## 7. Notes

- Database is SQLite (`backend/careerai.db`), created automatically on first
  run — delete the file to reset all data.
- File uploads accept PDF, DOCX, and TXT resumes.
- The seed data intentionally includes one scammy job listing so you can see
  AI Job Safety Analysis flag it in both the seeker and admin views.
